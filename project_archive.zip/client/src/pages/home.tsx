import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ExternalLink, FileCode, TestTube } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen w-full bg-background p-8 font-sans">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="space-y-2">
          <h1 className="text-4xl font-bold tracking-tight text-foreground">Лабораторна робота 6</h1>
          <p className="text-xl text-muted-foreground">E2E тести та screenshot тести</p>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <Card className="border-l-4 border-l-primary transition-all hover:shadow-md">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileCode className="h-5 w-5 text-primary" />
                Локальна сторінка
              </CardTitle>
              <CardDescription>
                HTML сторінка для тестування форми входу
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4 text-sm text-muted-foreground">
                Це статична сторінка, яку ми створили для відпрацювання E2E тестів.
                Вона містить форму входу з валідацією.
              </p>
              <Button asChild className="w-full group">
                <a href="/lab6-login.html" target="_blank">
                  Відкрити сторінку
                  <ExternalLink className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </a>
              </Button>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-secondary transition-all hover:shadow-md">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TestTube className="h-5 w-5 text-secondary" />
                E2E Тести
              </CardTitle>
              <CardDescription>
                Запуск та перевірка тестів
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4 text-sm text-muted-foreground">
                Тести Playwright налаштовані та знаходяться в папці <code>tests/e2e</code>.
                Ви можете запускати їх через консоль.
              </p>
              <div className="rounded-md bg-muted p-3 font-mono text-sm">
                npx playwright test
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
