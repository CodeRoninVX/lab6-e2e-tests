import { test, expect } from '@playwright/test';

test.describe('Screenshot Tests', () => {
  test('Page 2 Screenshot', async ({ page }) => {
    await page.goto('/lab6-page2.html');
    // Wait for image to load
    await page.waitForLoadState('networkidle');
    await expect(page).toHaveScreenshot('page2-full.png');
  });

  test('Button Screenshot', async ({ page }) => {
    await page.goto('/lab6-page2.html');
    const button = page.locator('#actionButton');
    await expect(button).toHaveScreenshot('page2-button.png');
  });
});
