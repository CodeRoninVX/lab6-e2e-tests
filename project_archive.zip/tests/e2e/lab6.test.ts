import { test, expect } from '@playwright/test';

test.describe('Lab 6 E2E Tests', () => {

  test('Валідний логін', async ({ page }) => {
    await page.goto('/lab6-login.html');
    await page.fill('#username', 'test_user');
    await page.fill('#password', 'password123');
    await page.click('#loginButton');
    await expect(page.locator('#successMessage')).toBeVisible();
    await expect(page.locator('#successMessage')).toHaveText('Успішний вхід!');
  });

  test('Невалідний логін (перевірка відсутності успіху)', async ({ page }) => {
    await page.goto('/lab6-login.html');
    // Not filling anything or filling wrong data won't trigger validation in the simple HTML example unless we check :invalid
    // But let's check that success message is NOT visible initially
    await expect(page.locator('#successMessage')).toBeHidden();
  });

  test('Пусті поля (валідація)', async ({ page }) => {
    await page.goto('/lab6-login.html');
    await page.click('#loginButton');
    
    // Check if any input is invalid using evaluate
    const isInvalid = await page.evaluate(() => {
        const inputs = document.querySelectorAll('input:invalid');
        return inputs.length > 0;
    });
    expect(isInvalid).toBeTruthy();
  });

  test('Проверка кнопки на новой странице', async ({ page }) => {
    await page.goto('/lab6-page2.html');
    const button = page.locator('#actionButton');
    await expect(button).toBeVisible();
    await expect(button).toHaveText('Натисни мене');
  });

  test('Проверка отображения текста', async ({ page }) => {
    await page.goto('/lab6-page2.html');
    await expect(page.locator('#pageTitle')).toHaveText('Вітаємо на сторінці 2');
    await expect(page.locator('#pageText')).toContainText('Це тестова сторінка');
  });

});
