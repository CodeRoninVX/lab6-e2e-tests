# Page snapshot

```yaml
- generic [ref=e2]:
  - heading "Змінений Заголовок" [level=1] [ref=e3]
  - img "Abstract Geometry" [ref=e4]
  - paragraph [ref=e5]: Текст змінено для перевірки помилки в тестах.
  - button "Натисни мене" [ref=e6] [cursor=pointer]
```